//#include <string.h>
#include "main.h"

unsigned char* vram = (uchar*)0xbc00;
extern uchar color_dot[];
extern uchar color_line[];


unsigned char sprite1[19] = {0x0f,0xf0,0xff, 0xf0,0xff,0x0f, 0x0f,0xf0,0xff, 0xf0,0xff,0x0f, 0x0f,0xf0,0xff, 0xf0,0xff,0x0f, 0};
unsigned char sprite2[19] = {0xf0,0xff,0x0f, 0x0f,0xf0,0xff, 0xf0,0xff,0x0f, 0x0f,0xf0,0xff, 0xf0,0xff,0x0f, 0x0f,0xf0,0xff,  0};

void clear_screen(void)
{
#asm
    mvi c,1fh
    call 0f809h
   
#endasm
}



void exit_monitor(void)
{
#asm
    jmp 0f86ch
   
#endasm
}


void main() {

clear_screen();
init_mass();
init_screen(color_mode);//



lcdPrintText("������ ����", 1, 10, 0,green);
lcdPrintText("������ ����", 1, 20, 0,red);
lcdPrintText("������ ����", 1, 30, 0,blue);

put_color_line(1,1, 239, 1, blue);
Put_Rect(120, 10, 100, 100, 1,red);
//put_sprite(100,10,sprite,6,3);
//exit_monitor();
  while(1) 
  {
   put_sprite(100,100,sprite1,6,3);
   put_sprite(112,100,sprite1,6,3);
   put_sprite(100,106,sprite1,6,3);
   put_sprite(112,106,sprite1,6,3);

   put_sprite(100,100,sprite2,6,3); 
   put_sprite(112,100,sprite2,6,3);
   put_sprite(100,106,sprite2,6,3); 
   put_sprite(112,106,sprite2,6,3); 
  }
}

 