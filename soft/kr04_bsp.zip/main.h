#ifndef __MAIN_H
#define __MAIN_H

#define red   3
#define green 2
#define blue  1
#define black 0 

#define uchar unsigned char
#define uint  unsigned int
#define bool  unsigned char
#define int16_t int
#define uint8_t unsigned char
#define uint16_t unsigned int
#define int8_t char
#define u8 uchar

#define true  1
#define false 0
#define VIDEO_BPL 78

#define SCREEN 0xbc00

#define color_mode 1
#define bw_mode 3
#define text_mode 2


#define pgm_read_byte(x) (*((uint8_t*)x))


void init_mass(void);
void set_grapf_mass(void);
void put_text(uchar* a,uchar x,uchar y, uchar* text);
uchar lcdPrintText(char const *ptrText, uchar x, uchar y, uchar font,uchar color);
void clear_chargen_ram(void);
void SetPixel(int x, uchar y);
void ClearPixel(int x, uchar y);
void LCD_Rect(int xPos, uchar yPos, int width, uchar height, unsigned char filled,uchar color);
void LCD_HLine(int xPos, int yPos, int width, uchar color);
void lcd_line(int x0, int x1, int y0, int y1, uchar color);
void put_char(uchar x, uchar y, uchar chr, uchar font,uchar color);
void put_color_dot(uchar x,uchar y, uchar color);
void put_color_line(uchar x,uchar y, uchar xe,uchar ye, uchar color);
void Put_Rect(int xPos, uchar yPos, int width, uchar height, unsigned char filled,uchar color);
void init_screen(uchar mode);
void put_sprite(uchar x,uchar y,uint8_t* p,uchar m,uchar k);

void ResetVariables();


#endif 