//#include <string.h>
#include"main.h"
#include "fonts.h"
extern uchar* vram;




void delay(int z)
{
  while(z--);
}
void clear_chargen_ram(void)
{
int n;
 for (n=0;n<14336;n++)
 {
  vram[n]=0x00;

  
 }
}

void put_bitmap(uchar* bmp,int x,char xb,int len)
{
int n=x;
int mass;
int pointer=0;
 while(len>0)
 {
for (mass=0;mass<xb;mass++)
  {
   vram[n+mass]=bmp[pointer++];
   len--;
  }
   n+=64;
}
}

void SetPixel(int x, uchar y){
 int addr;
 uchar cc;
 addr = (y<<6)|(x>>3);//
 cc = 1<<(x&7);   
 vram[addr] |= cc; 
}

void ClearPixel(int x, uchar y){
 int addr;
 uchar cc;
 addr = (y<<6)|(x>>3);//
 cc = 1<<(x&7);   
 vram[addr] &= ~cc;
}
/**/
void DrawPixel(int x, int y,uchar color){
 /*int addr;
 uchar cc;
   
   addr = (y<<6)|(x>>3);//
    cc = 1<<(x&7);//
    
  if (color)
{
 vram[addr] |= cc;
}
else
{
 vram[addr] &= ~cc;
}
 */
 
}

void lcd_line(int x0, int x1, int y0, int y1, uchar color){
    
    int dy, dx, fraction;
    int stepx, stepy;
    dy = y1 - y0;
    dx = x1 - x0;
    if(dy < 0){
        dy = -dy;
        stepy = -1;
    } else{
        stepy = 1;
    }
    if(dx < 0){
        dx = -dx;
        stepx = -1;
    } else{
        stepx = 1;
    }
    dy <<= 1;
    dx <<= 1;

    put_color_dot(x0,y0,color);//DrawPixel(x0, y0,color);
    if(dx > dy){
        fraction = dy - (dx >> 1);
        while(x0 != x1){
            if(fraction >= 0){
                y0 += stepy;
                fraction -= dx;
            }
            x0 += stepx;
            fraction += dy;
            put_color_dot(x0,y0,color);//DrawPixel(x0, y0,color);
        }
    } else{
        fraction = dx - (dy >> 1);
        while(y0 != y1){
            if(fraction >= 0){
                x0 += stepx;
                fraction -= dy;
            }
            y0 += stepy;
            fraction += dx;
            put_color_dot(x0,y0,color);//DrawPixel(x0, y0,color);
        }
    }
}

void LCD_HLine(int xPos, int yPos, int width, uchar color){
    put_color_dot(xPos + width - 1, yPos, color);//SetPixel(xPos + width - 1, yPos);
    put_color_dot(xPos, yPos,color);//SetPixel(xPos, yPos);
    while(width){
        put_color_dot(xPos, yPos,color);//SetPixel(xPos, yPos);
        xPos++;
        width--;
    }
}
//-----

void LCD_Rect(int xPos, uchar yPos, int width, uchar height, unsigned char filled,uchar color){
    unsigned int y;
    LCD_HLine(xPos, yPos, width,color);
    LCD_HLine(xPos, yPos + height - 1, width,color);

    if(filled == 1){
        for(y = 1; y < height; y++){
            LCD_HLine(xPos, yPos + y, width,color);
        }
    } else{
        for(y = 1; y < height; y++){
            put_color_dot(xPos, yPos + y,color);//SetPixel(xPos, yPos + y);
            put_color_dot(xPos + width - 1, yPos + y,color);//SetPixel(xPos + width - 1, yPos + y);
        }
    }
}

void put_char(uchar x, uchar y, uchar chr, uchar orientation, uchar font,uchar color){
    unsigned char h, ch, p, mask, q;
    int xx, yy;
    xx = x;
    yy = y;
    if(font == 1) q = 8;
    if(font == 0) q = 14;
    if(chr == 0xb8){ // �
        chr = 0x101;
    }
    if(chr == 0xa8) chr = 0x100; // �
    for(h = q; h > 0; h--) // ������ ������ ������� (����)
    {
        if(!orientation){
            if(chr < 0xc0){
                if(font) ch = font_8x8[ chr - 32 ][h];
                else
                    ch = font_8x14[ chr - 32 ][h];
            }
            else{
                if(font) ch = font_8x8[ chr - 96 ][h];
                else
                    ch = font_8x14[ chr - 96 ][h];
            }
        } else{
            if(chr < 0xc0){
                if(font) ch = font_8x8[ chr - 32 ][h - 1];
                else
                    ch = font_8x14[ chr - 32 ][h];
            } else{
                if(font) ch = font_8x8[ chr - 96 ][h - 1];
                else
                    ch = font_8x14[ chr - 96 ][h];
            }
        }
        mask = 0x80;
        if(orientation){
            xx = x;
        } else{
            yy = y;
        }
        for(p = 0; p < 8; p++) //������������ ������� ������ �������
        {
            if(ch & mask){put_color_dot(xx,yy,color);}// SetPixel(xx, yy);  //SetPixel(xx, yy); // 
            // else{
            // put_color_dot(xx,yy,black);//ClearPixel(xx, yy);    // DrawPixel(xx, yy,0);
            //}
            mask = mask / 2;
            if(orientation)
                xx++;
            else
                yy++;
        }
        if(orientation)yy++;
        else xx++;
    }
}

uchar lcdPrintText(char const *ptrText, uchar x, uchar y, uchar orientation, uchar font,uchar color){
    if(orientation){
        for(; *ptrText; ptrText++){
            put_char(x, y, *ptrText, orientation, font, color);
            if(orientation){
                if(font == 2) x += 6;
                else x += 8;
            } else y += 8;
        }
    } else{
        for(; *ptrText; ptrText++){
            put_char(y, x, *ptrText, orientation, font,color);
            if(orientation){
                y += 8;
            } else{
                if(font == 2) x += 6;
                else x += 8;
            }
        }
    }
   if(orientation)return x;
    return y;
}


