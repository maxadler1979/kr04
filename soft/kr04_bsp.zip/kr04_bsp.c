#include "main.h"
#include "fonts.h"

extern uchar* vram;
extern unsigned char sprite[];
uchar color_dot[7];
uchar color_line[11];
uchar mode_mass[4];
uchar block_mass[9];

typedef struct 
{
  uchar ar2_set;
  uchar mode;
  uchar x;
  uchar y;
  uchar Haddr;
  uchar Laddr;
  
  uchar m;
  uchar k;
  uchar end;
}Block_t;

typedef struct 
{
 uchar colorset;
 uchar color;
 uchar coord_set;
 uchar coord_high; 
 uchar x;
 uchar y;
 uchar end;
}Dot_t;

typedef struct 
{
 uchar colorset;
 uchar color;
 uchar coord_set;
 uchar coord_dot; 
 uchar x;
 uchar y;
 uchar ar2_set;
 uchar coord_line;
 uchar xe;
 uchar ye;
 uchar end;
}Line_t;

Dot_t *Dot;
Line_t *Line; 
Block_t *Block;

void init_screen(uchar mode)
{
 #asm
 ld hl,2
 add hl,sp
 ld a,(hl)
 sta 0f604h
 call 0f82dh
 #endasm

}


void init_mass(void)
{
color_dot[0]=0x1b;
color_dot[2]=0x1b;
color_dot[3]=0x04;
color_dot[7]=0x00;

color_line[0]=0x1b;
color_line[2]=0x1b;
color_line[3]=0x04;
color_line[6]=0x1b;
color_line[7]=0x06;
color_line[10]=0x00;

block_mass[0] = 0x1b;
block_mass[1] = 0x08;

block_mass[8] = 0;
}

void put_sprite(uchar x,uchar y,uint8_t* p,uchar m,uchar k)
{
Block = (Block_t*) block_mass;
Block->x = x;
Block->y = y;
Block->Haddr = *(((char*)(&p))+1);
Block->Laddr = p;
Block->m = m;
Block->k = k;
#asm
lxi h,_block_mass
call 0f818h
#endasm
}


//uchar color_dot[6] = {0x1b,green,0x1e,global_x,global_y};

void put_color_dot(uchar x,uchar y, uchar color)
{
 Dot  = (Dot_t *) color_dot;
 Dot->color =       color;
 Dot->x =           x;
 Dot->y =           y; 
 
#asm
lxi h,_color_dot
call 0f818h
#endasm
}

void put_color_line(uchar x,uchar y, uchar xe, uchar ye, uchar color)
{
 Line  = (Line_t *) color_line;
 Line->color =       color;
 Line->x =           x;
 Line->y =           y; 
 Line->xe =          xe;
 Line->ye =          ye;
#asm
lxi h,_color_line
call 0f818h
#endasm
}

void Put_HLine(int xPos, int yPos, int width, uchar color){
put_color_line(xPos,yPos, xPos+width, yPos, color);
}

void Put_Rect(int xPos, uchar yPos, int width, uchar height, unsigned char filled,uchar color){
    unsigned int y;
    Put_HLine(xPos, yPos, width,color);
    Put_HLine(xPos, yPos + height, width,color);

    if(filled == 1){
        for(y = 1; y < height; y++){
            Put_HLine(xPos, yPos + y, width,color);
        }
    } else{
       put_color_line(xPos,yPos, xPos, yPos+height, color);
       put_color_line(xPos+ width,yPos+height, xPos+ width, yPos, color);

        
    }
}

void put_char(uchar x, uchar y, uchar chr, uchar font, uchar color){
    unsigned char h, ch, p, mask, q;
    int xx, yy;
    xx = x;
    yy = y;
    if(font == 1) q = 8;
    if(font == 0) q = 14;
    //if(chr == 0xb8){ // �
    //    chr = 0x101;
    //}
    //if(chr == 0xa8) chr = 0x100; // �
    for(h = q; h > 0; h--) // ������ ������ ������� (����)
    {
    
            if(chr < 0xc0){
                if(font) ch = font_8x8[ chr - 32 ][h - 1];
                else
                    ch = font_8x14[ chr - 32 ][h];
            } else{
                if(font) ch = font_8x8[ chr - 96 ][h - 1];
                else
                    ch = font_8x14[ chr - 96 ][h];
            }
        
        mask = 0x80;
        xx = x;
        for(p = 0; p < 8; p++) //������������ ������� ������ �������
        {
            if(ch & mask){put_color_dot(xx,yy,color);}
            mask = mask / 2;
            xx++;
        }
        yy++;
    }
}

uchar lcdPrintText(char const *ptrText, uchar x, uchar y, uchar font,uchar color){
        for(; *ptrText; ptrText++)
        {
          put_char(x, y, *ptrText,  font, color);
          x += 8;
        }
    return x;
}

void ClearPixel(int x, uchar y){
 int addr;
 uchar cc;
 addr = (y<<6)|(x>>3);//
 cc = 1<<(x&7);   
 vram[addr] &= ~cc;
}

void SetPixel(int x, uchar y){
 int addr;
 uchar cc;
 addr = (y<<6)|(x>>3);//
 cc = 1<<(x&7);   
 vram[addr] |= cc; 
}





